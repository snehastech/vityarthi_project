import time, tracemalloc
import math

def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    r = int(math.sqrt(n))
    for i in range(3, r+1, 2):
        if n % i == 0:
            return False
    return True

def is_fibonacci(n):
    x1 = 5*n*n + 4
    x2 = 5*n*n - 4
    return int(math.isqrt(x1))**2 == x1 or int(math.isqrt(x2))**2 == x2

def is_fibonacci_prime(n):
    return is_prime(n) and is_fibonacci(n)

tracemalloc.start()
t0 = time.time()

res = is_fibonacci_prime(13)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
