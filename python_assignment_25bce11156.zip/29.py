import time, tracemalloc

def polygonal_number(s, n):
    return ((s-2)*n*(n-1))//2 + n

tracemalloc.start()
t0 = time.time()

res = polygonal_number(5, 7)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
