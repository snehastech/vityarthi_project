import time, tracemalloc, math

def is_mersenne_prime(p: int) -> bool:
    if p < 2: return False
    if p == 2: return True
    if p % 2 == 0: return False
    for a in range(3, int(math.isqrt(p)) + 1, 2):
        if p % a == 0: return False
    M = (1 << p) - 1
    s = 4
    for _ in range(p - 2):
        s = (s * s - 2) % M
    return s == 0

tracemalloc.start()
t0 = time.time()
res = is_mersenne_prime(19)
exec_time = time.time() - t0
mem = tracemalloc.get_traced_memory()[1]
tracemalloc.stop()
print("Result:", res)
print("Time:", exec_time, "s")
print("Memory:", mem, "bytes")
