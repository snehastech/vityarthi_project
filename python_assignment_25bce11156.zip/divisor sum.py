import time
import tracemalloc
import sys

def divisor_sum(n):
    total_sum = 0
    for i in range(1, n + 1):
        if n % i == 0:
            total_sum = total_sum + i
    return total_sum

tracemalloc.start()
start_time = time.time()
test_number = 1000
sum_of_divisors = divisor_sum(test_number)
end_time = time.time()
snapshot = tracemalloc.take_snapshot()
top_stats = snapshot.statistics('lineno')

# --- Calculate and Print Results ---
execution_time = (end_time - start_time) * 1000
total_memory_bytes = 0
for stat in top_stats:
    total_memory_bytes += stat.size

print("Test Number (n):", test_number)
# FIX: Replaced the problematic Unicode character (\u03c3) with "Divisor Sum"
print("Divisor Sum (n):", sum_of_divisors) 
print("\n--- Performance Results ---")
print("Execution Time (milliseconds):", f"{execution_time:.4f}")
print("Memory Utilization (bytes):", total_memory_bytes)

tracemalloc.stop()