import time
import sys

def mobius(n):
    if n == 1:
        return 1

    prime_factors_count = 0
    d = 2
    temp_n = n

    while d * d <= temp_n:
        if temp_n % d == 0:
            if temp_n % (d * d) == 0:
                return 0
            
            prime_factors_count += 1
            temp_n //= d
        d += 1

    if temp_n > 1:
        prime_factors_count += 1
    if prime_factors_count % 2 == 0:
        return 1
    else:
        return -1

# --- Example Usage ---
n_value = 30 # Example number
result = mobius(n_value)

# --- Measurement Code ---
start_time = time.time()
mobius(n_value)
end_time = time.time()
execution_time = (end_time - start_time) * 1000 # Time in milliseconds
memory_bytes = sys.getsizeof(mobius)

print(f"The Mobius function m({n_value}) is: {result}") 
print(f"Execution Time (ms): {execution_time}")
print(f"Memory Utilization (bytes): {memory_bytes}")