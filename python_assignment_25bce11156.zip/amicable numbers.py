import time, tracemalloc, math

def aliquot_sum(n):
    s=1
    r=int(math.isqrt(n))
    for i in range(2,r+1):
        if n%i==0:
            s+=i
            j=n//i
            if j!=i and j!=n: s+=j
    return 0 if n==1 else s

def are_amicable(a,b):
    return aliquot_sum(a)==b and aliquot_sum(b)==a

tracemalloc.start()
t0=time.time()
x=are_amicable(220,284)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()

print("are_amicable(220,284) =",x)
print("time =",t1-t0,"seconds")
print("memory =",peak,"bytes")
