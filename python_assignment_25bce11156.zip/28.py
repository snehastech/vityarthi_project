import time, tracemalloc

def collatz_length(n):
    c = 0
    while n != 1:
        n = n//2 if n%2==0 else 3*n+1
        c += 1
    return c

tracemalloc.start()
t0 = time.time()

res = collatz_length(27)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
