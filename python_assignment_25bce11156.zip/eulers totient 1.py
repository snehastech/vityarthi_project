# Program to calculate Euler's Totient Function (phi), execution time, and memory utilization.

import time
import sys

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def euler_phi(n):
    if n <= 0:
        return 0
    count = 0
    for k in range(1, n + 1):
        if gcd(n, k) == 1:
            count += 1
    return count

def measure_performance(n):
    start_time = time.time()
    result = euler_phi(n)
    end_time = time.time()
    execution_time = end_time - start_time

    func_size = sys.getsizeof(euler_phi)
    result_size = sys.getsizeof(result)
    memory_utilization = func_size + result_size

    print(f"Euler's Totient Function phi({n}) = {result}")
    print(f"Execution Time: {execution_time:.6f} seconds")
    print(f"Basic Memory Utilization Estimate: {memory_utilization} bytes")
    print(f"(Includes the size of the function object and the result value)")

    return result, execution_time, memory_utilization
N_VALUE = 5000
measure_performance(N_VALUE)