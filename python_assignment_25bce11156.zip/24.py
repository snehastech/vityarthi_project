import time, tracemalloc

def order_mod(a, n):
    a %= n
    if a == 0:
        return None
    k = 1
    val = a % n
    while val != 1:
        val = (val * a) % n
        k += 1
        if k > n:
            return None
    return k

tracemalloc.start()
t0 = time.time()

res = order_mod(3, 10)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
