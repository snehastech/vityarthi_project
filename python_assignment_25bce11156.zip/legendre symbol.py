import time
import sys

def legendre_symbol(a, p):
    a = a % p
    exponent = (p - 1) // 2
    result_mod_p = pow(a, exponent, p)
    
    if result_mod_p == p - 1:
        return -1
    else:
        return result_mod_p

a_val = 3
p_val = 17

# Time calculation
start_time = time.perf_counter_ns()
symbol = legendre_symbol(a_val, p_val)
end_time = time.perf_counter_ns()
execution_time = (end_time - start_time) / 1000000

memory_symbol = sys.getsizeof(symbol)
memory_a = sys.getsizeof(a_val)
memory_p = sys.getsizeof(p_val)
memory_total = memory_symbol + memory_a + memory_p

# --- Results ---

print(f"Legendre Symbol ({a_val}/{p_val}): {symbol}")
print("---")
print(f"Execution Time: {execution_time:.3f} milliseconds")
print(f"Memory Utilization: {memory_total} bytes (approx. for key variables)")