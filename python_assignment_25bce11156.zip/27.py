import time, tracemalloc
import math

def is_perfect_power(n):
    if n <= 1:
        return False
    for b in range(2, int(math.log2(n)) + 2):
        a = round(n ** (1 / b))
        if a > 1 and a ** b == n:
            return True
    return False

tracemalloc.start()
t0 = time.time()

res = is_perfect_power(64)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
