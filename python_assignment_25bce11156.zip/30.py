import time, tracemalloc
import math

def is_carmichael(n):
    if n < 2 or all(n % i for i in range(2, int(n**0.5) + 1)):
        return False
    for a in range(2, n):
        if math.gcd(a, n) == 1:
            if pow(a, n-1, n) != 1:
                return False
    return True

tracemalloc.start()
t0 = time.time()

res = is_carmichael(561)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
