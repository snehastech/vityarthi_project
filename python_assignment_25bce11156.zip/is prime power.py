import time, tracemalloc, math
def is_prime_power(n):
    tracemalloc.start();t=time.time()
    if n<2:return False
    for p in range(2,int(math.sqrt(n))+1):
        if n%p==0:
            k=n
            while k%p==0:k//=p
            if k==1:
                mem=tracemalloc.get_traced_memory()[1]
                tracemalloc.stop()
                print(f"Execution time: {time.time()-t:.8f}s, Memory: {mem} bytes")
                return True
    mem=tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    print(f"Execution time: {time.time()-t:.8f}s, Memory: {mem} bytes")
    return True if n>1 else False

print(is_prime_power(27))
