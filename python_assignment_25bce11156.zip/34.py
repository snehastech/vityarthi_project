import time, tracemalloc

def partition_function(n):
    dp=[0]*(n+1)
    dp[0]=1
    for i in range(1,n+1):
        for j in range(i,n+1):
            dp[j]+=dp[j-i]
    return dp[n]

tracemalloc.start()
t0=time.time()
res=partition_function(5)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()
tracemalloc.stop()

print(res)
print("Time:",t1-t0,"sec")
print("Memory:",peak,"bytes")
