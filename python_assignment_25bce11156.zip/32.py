import time, tracemalloc
import random, math

def pollard_rho(n):
    if n % 2 == 0:
        return 2
    if n < 3:
        return None
    x = random.randint(2, n - 2)
    y = x
    c = random.randint(1, n - 1)

    while True:
        x = (x*x + c) % n
        y = (y*y + c) % n
        y = (y*y + c) % n
        d = math.gcd(abs(x - y), n)
        if d == 1:
            continue
        if d == n:
            return None
        return d

tracemalloc.start()
t0 = time.time()

res = pollard_rho(8051)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
