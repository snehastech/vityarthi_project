import time, tracemalloc, math
def count_distinct_prime_factors(n):
    tracemalloc.start();t=time.time()
    c,i=0,2
    while i*i<=n:
        if n%i==0:
            c+=1
            while n%i==0:n//=i
        i+=1
    if n>1:c+=1
    mem=tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    print(f"Execution time: {time.time()-t:.8f}s, Memory: {mem} bytes")
    return c

print(count_distinct_prime_factors(100))
