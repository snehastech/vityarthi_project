import time, tracemalloc

def zeta_approx(s, terms):
    x = 0
    for n in range(1, terms + 1):
        x += 1 / (n**s)
    return x

tracemalloc.start()
t0 = time.time()

res = zeta_approx(2, 10000)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
