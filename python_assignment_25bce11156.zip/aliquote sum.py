import time, tracemalloc, math

def aliquot_sum(n):
    s=1
    r=int(math.isqrt(n))
    for i in range(2,r+1):
        if n%i==0:
            s+=i
            j=n//i
            if j!=i and j!=n: s+=j
    return 0 if n==1 else s

tracemalloc.start()
t0=time.time()
x=aliquot_sum(1000)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()

print("aliquot_sum(1000) =",x)
print("time =",t1-t0,"seconds")
print("memory =",peak,"bytes")
