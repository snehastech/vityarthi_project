import time, tracemalloc

def mod_inverse(a, m):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None

def crt(remainders, moduli):
    M = 1
    for m in moduli:
        M *= m
    x = 0
    for r, m in zip(remainders, moduli):
        Mi = M // m
        inv = mod_inverse(Mi, m)
        x += r * Mi * inv
    return x % M

tracemalloc.start()
t0 = time.time()

res = crt([2, 3, 2], [3, 5, 7])

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
