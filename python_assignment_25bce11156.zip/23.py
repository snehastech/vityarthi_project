import time, tracemalloc

def is_quadratic_residue(a, p):
    a %= p
    if a == 0:
        return True
    return pow(a, (p - 1) // 2, p) == 1

tracemalloc.start()
t0 = time.time()

res = is_quadratic_residue(10, 13)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()