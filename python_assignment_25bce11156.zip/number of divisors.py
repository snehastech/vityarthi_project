import time, tracemalloc, math

def count_divisors(n):
    c = 0
    for i in range(1, int(math.isqrt(n)) + 1):
        if n % i == 0:
            c += 2 if i * i != n else 1
    return c

tracemalloc.start()
t0 = time.time()
res = count_divisors(1000)
exec_time = time.time() - t0
mem = tracemalloc.get_traced_memory()[1]
tracemalloc.stop()
print("Result:", res)
print("Time:", exec_time, "s")
print("Memory:", mem, "bytes")
