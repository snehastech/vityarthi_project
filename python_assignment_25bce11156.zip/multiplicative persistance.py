import time, tracemalloc

def multiplicative_persistence(n):
    c=0
    while n>9:
        p=1
        for d in str(n): p*=int(d)
        n=p
        c+=1
    return c

tracemalloc.start()
t0=time.time()
x=multiplicative_persistence(999)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()

print("multiplicative_persistence(999) =",x)
print("time =",t1-t0,"seconds")
print("memory =",peak,"bytes")
