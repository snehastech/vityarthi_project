import time
import sys

def is_prime(k):
    if k < 2:
        return False
    # Check for divisibility from 2 up to the square root of k
    i = 2
    while i * i <= k:
        if k % i == 0:
            return False
        i += 1
    return True

def prime_pi(n):
    if n < 0:
        raise ValueError("n must be a non-negative integer")

    count = 0
    # Loop through all numbers from 2 up to n
    for num in range(2, n + 1):
        if is_prime(num):
            count += 1
    return count

def measure_prime_pi(n):
    start_time = time.time()
    result = prime_pi(n)
    end_time = time.time()

    execution_time = end_time - start_time
    memory_usage = sys.getsizeof(result)

    return result, execution_time, memory_usage

# Example Usage
n_value = 100
result, time_taken, memory_used = measure_prime_pi(n_value)

print(f"The number of primes less than or equal to {n_value} (pi({n_value})) is: {result}")
print(f"Execution Time: {time_taken:.6f} seconds")
print(f"Memory Utilization: {memory_used} bytes")