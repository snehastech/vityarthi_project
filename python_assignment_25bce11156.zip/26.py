import time, tracemalloc

def lucas_sequence(n):
    if n <= 0:
        return []
    if n == 1:
        return [2]
    seq = [2, 1]
    for i in range(2, n):
        seq.append(seq[-1] + seq[-2])
    return seq

tracemalloc.start()
t0 = time.time()

res = lucas_sequence(10)

t1 = time.time()
current, peak = tracemalloc.get_traced_memory()

print("Result:", res)
print("Time:", t1 - t0)
print("Memory:", peak)

tracemalloc.stop()
