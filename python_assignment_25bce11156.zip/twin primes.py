import time, tracemalloc, math

def is_prime(n):
    if n < 2: return False
    if n == 2: return True
    if n % 2 == 0: return False
    for i in range(3, int(math.isqrt(n)) + 1, 2):
        if n % i == 0: return False
    return True

def twin_primes(limit):
    twins = []
    for n in range(3, limit, 2):
        if is_prime(n) and is_prime(n + 2):
            twins.append((n, n + 2))
    return twins

tracemalloc.start()
t0 = time.time()
res = twin_primes(1000)
exec_time = time.time() - t0
mem = tracemalloc.get_traced_memory()[1]
tracemalloc.stop()
print("Result:", res)
print("Time:", exec_time, "s")
print("Memory:", mem, "bytes")
