import time
import sys
import tracemalloc

def is_deficient(n):
    if n <= 0:
        raise ValueError("Input must be a positive integer.")
    
    sum_proper_divisors = 0
    
    for i in range(1, n // 2 + 1):
        if n % i == 0:
            sum_proper_divisors += i
            
    return sum_proper_divisors < n

# --- Test and Metrics ---
N = 1000

tracemalloc.start()

start_time = time.time()
result = is_deficient(N)
end_time = time.time()

current, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()

print(f"Number tested: {N}")
print(f"Is Deficient: {result}")
print(f"Execution Time: {end_time - start_time:.6f} seconds")
print(f"Peak Memory Utilization: {peak} bytes")
print(f"Result variable size: {sys.getsizeof(result)} bytes")