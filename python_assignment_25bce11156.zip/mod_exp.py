import time, tracemalloc

def mod_exp(b,e,m):
    r=1
    while e>0:
        if e&1: r=(r*b)%m
        b=(b*b)%m
        e//=2
    return r

tracemalloc.start()
t0=time.time()
x=mod_exp(7,128,1000)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()

print("mod_exp(7,128,1000) =",x)
print("time =",t1-t0,"seconds")
print("memory =",peak,"bytes")
