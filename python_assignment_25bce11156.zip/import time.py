import time
import sys
import tracemalloc

def prime_factors(n):
    if n <= 1:
        return []
    
    factors = []
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors.append(d)
            n //= d
        d += 1
    if n > 1:
        factors.append(n)
    return factors

# --- Test and Metrics ---
N = 100

tracemalloc.start()

start_time = time.time()
result = prime_factors(N)
end_time = time.time()

current, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()

print(f"Number tested: {N}")
print(f"Prime Factors: {result}")
print(f"Execution Time: {end_time - start_time:.6f} seconds")
print(f"Peak Memory Utilization: {peak} bytes")
print(f"Result variable size: {sys.getsizeof(result)} bytes")