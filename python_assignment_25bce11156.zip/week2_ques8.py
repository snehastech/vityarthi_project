import time
import sys
import tracemalloc

def is_automorphic(n):
    if n <= 0:
        raise ValueError("Input must be a positive integer.")
    
    square = n * n
    n_str = str(n)
    square_str = str(square)
        
    return square_str.endswith(n_str)

# --- Test and Metrics ---
N = 76

tracemalloc.start()

start_time = time.time()
result = is_automorphic(N)
end_time = time.time()

current, peak = tracemalloc.get_traced_memory()
tracemalloc.stop()

print(f"Number tested: {N}")
print(f"Is Automorphic: {result}")
print(f"Execution Time: {end_time - start_time:.6f} seconds")
print(f"Peak Memory Utilization: {peak} bytes")
print(f"Result variable size: {sys.getsizeof(result)} bytes")