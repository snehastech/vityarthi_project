import time, tracemalloc, math

def divs(n):
    c=0
    r=int(math.isqrt(n))
    for i in range(1,r+1):
        if n%i==0:
            c+=2 if i*i!=n else 1
    return c

def is_highly_composite(n):
    m=divs(n)
    for i in range(1,n):
        if divs(i)>=m: return False
    return True

tracemalloc.start()
t0=time.time()
x=is_highly_composite(12)
t1=time.time()
cur,peak=tracemalloc.get_traced_memory()

print("is_highly_composite(12) =",x)
print("time =",t1-t0,"seconds")
print("memory =",peak,"bytes")
